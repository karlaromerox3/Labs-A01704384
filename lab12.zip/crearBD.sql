DROP TABLE IF EXISTS Materiales;

CREATE TABLE Materiales(
    Clave numeric(5) not null,
    Descripcion varchar(50),
    Costo numeric(8,2)
);

DROP TABLE IF EXISTS Proveedores;

CREATE TABLE Proveedores(
    RFC char(15) not null,
    RazonSocial varchar(50)
);

DROP TABLE IF EXISTS Proyectos;

CREATE TABLE Proyectos(
    Numero numeric(5) not null,
    Denominacion varchar(50)
);

DROP TABLE IF EXISTS Entregan;

CREATE TABLE Entregan(
    Clave numeric(5) not null,
    RFC char(15) not null,
    Numero numeric(5) not null,
    Fecha DateTime not null,
    Cantidad numeric(8,2)
);


/*Carga de archivos*/
LOAD DATA INFILE 'proveedores.csv'
INTO TABLE lab11.Proveedores
FIELDS TERMINATED BY ',';

LOAD DATA INFILE 'materiales.csv'
INTO TABLE lab11.Materiales
FIELDS TERMINATED BY ',';

LOAD DATA INFILE 'proyectos.csv'
INTO TABLE lab11.Proyectos
FIELDS TERMINATED BY ',';

LOAD DATA INFILE 'entregan.csv'
INTO TABLE lab11.Entregan
FIELDS TERMINATED BY ','
(Clave,RFC,Numero, @Fecha,Cantidad)
SET Fecha = STR_TO_DATE(@Fecha, '%d/%m/%Y');


/*Ejercicio 2*/

  INSERT INTO Materiales values(1000, 'xxx', 1000)

   Delete from Materiales where Clave = 1000 and Costo = 1000

   
