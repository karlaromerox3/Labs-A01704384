UPDATE lab11.entregan SET Fecha = STR_TO_DATE(Fecha, '%d-%m-%y');

LOAD DATA INFILE 'entregan.csv'
INTO TABLE lab11.entregan
FIELDS TERMINATED BY ','