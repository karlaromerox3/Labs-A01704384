LOAD DATA INFILE 'proveedores.csv'
INTO TABLE lab11.proveedores
FIELDS TERMINATED BY ','