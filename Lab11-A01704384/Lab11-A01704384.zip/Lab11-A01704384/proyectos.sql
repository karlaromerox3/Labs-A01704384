LOAD DATA INFILE 'proyectos.csv'
INTO TABLE lab11.proyectos
FIELDS TERMINATED BY ','