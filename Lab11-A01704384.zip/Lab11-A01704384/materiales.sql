LOAD DATA INFILE 'materiales.csv'
INTO TABLE lab11.materiales
FIELDS TERMINATED BY ','